<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation" class="flex items-center justify-center gap-1">
        
        <?php if($paginator->onFirstPage()): ?>
            <span
                class="w-9 h-9 flex items-center justify-center rounded-lg text-gray-400 dark:text-slate-500 cursor-not-allowed">
                <i class="fas fa-chevron-left text-xs"></i>
            </span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>"
                class="ajax-pagination-link w-9 h-9 flex items-center justify-center rounded-lg text-gray-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                <i class="fas fa-chevron-left text-xs"></i>
            </a>
        <?php endif; ?>

        
        <?php
            $start = max($paginator->currentPage() - 2, 1);
            $end = min($start + 4, $paginator->lastPage());
            if ($end - $start < 4) {
                $start = max($end - 4, 1);
            }
        ?>

        
        <?php if($start > 1): ?>
            <a href="<?php echo e($paginator->url(1)); ?>"
                class="ajax-pagination-link w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium text-gray-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                1
            </a>
            <?php if($start > 2): ?>
                <span class="w-9 h-9 flex items-center justify-center text-gray-400 dark:text-slate-500 text-sm">...</span>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php for($page = $start; $page <= $end; $page++): ?>
            <?php if($page == $paginator->currentPage()): ?>
                <span
                    class="w-9 h-9 flex items-center justify-center rounded-lg text-sm font-bold bg-blue-600 text-white shadow-sm">
                    <?php echo e($page); ?>

                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->url($page)); ?>"
                    class="ajax-pagination-link w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium text-gray-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                    <?php echo e($page); ?>

                </a>
            <?php endif; ?>
        <?php endfor; ?>

        
        <?php if($end < $paginator->lastPage()): ?>
            <?php if($end < $paginator->lastPage() - 1): ?>
                <span class="w-9 h-9 flex items-center justify-center text-gray-400 dark:text-slate-500 text-sm">...</span>
            <?php endif; ?>
            <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>"
                class="ajax-pagination-link w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium text-gray-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                <?php echo e($paginator->lastPage()); ?>

            </a>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>"
                class="ajax-pagination-link w-9 h-9 flex items-center justify-center rounded-lg text-gray-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                <i class="fas fa-chevron-right text-xs"></i>
            </a>
        <?php else: ?>
            <span
                class="w-9 h-9 flex items-center justify-center rounded-lg text-gray-400 dark:text-slate-500 cursor-not-allowed">
                <i class="fas fa-chevron-right text-xs"></i>
            </span>
        <?php endif; ?>
    </nav>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/vendor/pagination/admin.blade.php ENDPATH**/ ?>