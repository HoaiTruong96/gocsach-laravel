<?php $__env->startSection('title', $author->name . ' - Góc Sách'); ?>

<?php $__env->startSection('content'); ?>
<section class="container mx-auto px-4 py-12">
    
    <div class="bg-white rounded-2xl shadow-sm p-6 md:p-8 mb-8">
        <div class="flex flex-col md:flex-row items-center md:items-start gap-6">
            
            <?php
                $photo = $author->photo ?? null;
                $photoUrl = $photo ? (Str::startsWith($photo, 'http') ? $photo : asset('storage/' . $photo)) : null;
            ?>
            <div class="w-32 h-32 rounded-full overflow-hidden bg-gray-100 flex-shrink-0">
                <?php if($photoUrl): ?>
                    <img src="<?php echo e($photoUrl); ?>" alt="<?php echo e($author->name); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-brand-green to-brand-accent text-white text-4xl font-bold">
                        <?php echo e(strtoupper(substr($author->name, 0, 1))); ?>

                    </div>
                <?php endif; ?>
            </div>

            
            <div class="flex-1 text-center md:text-left">
                <h1 class="text-3xl md:text-4xl font-bold font-serif text-gray-800 mb-2"><?php echo e($author->name); ?></h1>
                
                <div class="flex flex-wrap justify-center md:justify-start gap-4 text-sm text-gray-500 mb-4">
                    <?php if($author->nationality): ?>
                        <span class="flex items-center gap-1">
                            <i class="fas fa-globe-asia"></i> <?php echo e($author->nationality); ?>

                        </span>
                    <?php endif; ?>
                    <?php if($author->birth_year): ?>
                        <span class="flex items-center gap-1">
                            <i class="fas fa-birthday-cake"></i> 
                            <?php echo e($author->birth_year); ?><?php echo e($author->death_year ? ' - ' . $author->death_year : ''); ?>

                        </span>
                    <?php endif; ?>
                    <span class="flex items-center gap-1">
                        <i class="fas fa-book"></i> <?php echo e($books->total()); ?> sách
                    </span>
                </div>

                <?php if($author->bio): ?>
                    <p class="text-gray-600 leading-relaxed"><?php echo e($author->bio); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="mb-6">
        <h2 class="text-2xl font-bold font-serif text-gray-800 mb-1">Sách của <?php echo e($author->name); ?></h2>
        <p class="text-sm text-gray-500">Tổng cộng <?php echo e($books->total()); ?> đầu sách</p>
    </div>

    <?php if($books->count() > 0): ?>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('detail', $book->slug)); ?>" class="group">
                    <div class="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 transform group-hover:-translate-y-1">
                        
                        <div class="aspect-[2/3] bg-gray-100 overflow-hidden">
                            <?php if($book->cover_image): ?>
                                <img src="<?php echo e(Str::startsWith($book->cover_image, 'http') ? $book->cover_image : asset('storage/' . $book->cover_image)); ?>" 
                                    alt="<?php echo e($book->title); ?>" 
                                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-200 to-gray-300">
                                    <i class="fas fa-book text-4xl text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        
                        <div class="p-3">
                            <h3 class="font-semibold text-gray-800 text-sm line-clamp-2 group-hover:text-brand-green transition-colors"><?php echo e($book->title); ?></h3>
                            <?php if($book->avg_rating): ?>
                                <div class="flex items-center gap-1 mt-1">
                                    <i class="fas fa-star text-yellow-400 text-xs"></i>
                                    <span class="text-xs text-gray-500"><?php echo e(number_format($book->avg_rating, 1)); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mt-8 flex justify-center">
            <?php echo e($books->links()); ?>

        </div>
    <?php else: ?>
        <div class="bg-white rounded-xl p-12 text-center">
            <i class="fas fa-book-open text-5xl text-gray-300 mb-4"></i>
            <p class="text-gray-500">Chưa có sách nào của tác giả này</p>
        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/authors/show.blade.php ENDPATH**/ ?>