<?php if($paginator->hasPages()): ?>
    <nav class="flex items-center justify-center gap-1" role="navigation" aria-label="Pagination Navigation">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="inline-flex items-center justify-center w-10 h-10 text-gray-300 cursor-not-allowed rounded-lg">
                <i class="fas fa-chevron-left text-sm"></i>
            </span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" 
               class="inline-flex items-center justify-center w-10 h-10 text-gray-600 hover:text-white hover:bg-brand-green rounded-lg transition-all duration-200 shadow-sm border border-gray-100 hover:border-brand-green bg-white"
               rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                <i class="fas fa-chevron-left text-sm"></i>
            </a>
        <?php endif; ?>

        
        <div class="hidden sm:flex items-center gap-1">
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <span class="inline-flex items-center justify-center w-10 h-10 text-gray-400 text-sm font-medium">
                        <?php echo e($element); ?>

                    </span>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-gradient-to-r from-brand-green to-emerald-600 text-white font-bold text-sm rounded-lg shadow-md" aria-current="page">
                                <?php echo e($page); ?>

                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" 
                               class="inline-flex items-center justify-center w-10 h-10 text-gray-600 hover:text-white hover:bg-brand-green font-medium text-sm rounded-lg transition-all duration-200 shadow-sm border border-gray-100 hover:border-brand-green bg-white"
                               aria-label="<?php echo app('translator')->get('pagination.goto_page', ['page' => $page]); ?>">
                                <?php echo e($page); ?>

                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="sm:hidden px-4 py-2 text-sm text-gray-600 font-medium">
            <span class="text-brand-green font-bold"><?php echo e($paginator->currentPage()); ?></span>
            <span class="mx-1">/</span>
            <span><?php echo e($paginator->lastPage()); ?></span>
        </div>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" 
               class="inline-flex items-center justify-center w-10 h-10 text-gray-600 hover:text-white hover:bg-brand-green rounded-lg transition-all duration-200 shadow-sm border border-gray-100 hover:border-brand-green bg-white"
               rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                <i class="fas fa-chevron-right text-sm"></i>
            </a>
        <?php else: ?>
            <span class="inline-flex items-center justify-center w-10 h-10 text-gray-300 cursor-not-allowed rounded-lg">
                <i class="fas fa-chevron-right text-sm"></i>
            </span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>