<?php $__env->startSection('title', 'Trang Cá Nhân - ' . $user->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-brand-beige/30 py-4 border-b border-brand-beige">
        <div class="container mx-auto px-4">
            <div class="flex items-center text-sm text-gray-500 font-medium">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-brand-green transition">Trang chủ</a>
                <span class="mx-2 text-gray-300">/</span>
                <span class="text-brand-green font-bold">Hồ sơ của <?php echo e($user->name); ?></span>
            </div>
        </div>
    </div>

    <main class="container mx-auto px-4 py-12 flex-grow min-h-screen">
        
        <?php if(session('success')): ?>
            <div
                class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg relative shadow-sm flex items-center gap-3">
                <i class="fas fa-check-circle text-xl"></i>
                <span class="block sm:inline font-medium"><?php echo e(session('success')); ?></span>
                <button class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="this.parentElement.remove();">
                    <i class="fas fa-times text-green-500 hover:text-green-700"></i>
                </button>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">

            
            
            
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl shadow-soft p-6 text-center border border-gray-100">

                    <div class="relative w-52 h-52 mx-auto mb-4 group">
                        <!-- Avatar Frame Overlay (rendered first but z-index higher) -->
                        <?php
                            $equippedFrame = $user->equippedFrame();
                        ?>

                        <?php if($equippedFrame): ?>
                            <img src="<?php echo e(Str::startsWith($equippedFrame->frame_image, 'http') ? $equippedFrame->frame_image : asset('storage/' . $equippedFrame->frame_image)); ?>"
                                alt="Frame" class="absolute inset-0 w-full h-full object-contain pointer-events-none z-10">
                        <?php endif; ?>

                        <!-- User Avatar (fixed size, centered, behind frame) -->
                        <div class="absolute inset-0 flex items-center justify-center z-0">
                            <img src="<?php echo e($user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=3E5F4E&color=fff&size=128'); ?>"
                                class="w-32 h-32 rounded-full border-2 border-brand-beige shadow-md object-cover group-hover:border-brand-green transition duration-300">
                        </div>

                        <?php if(Auth::id() == $user->id): ?>
                            <button
                                class="absolute bottom-0 right-0 bg-white border border-gray-200 p-1.5 rounded-full text-gray-500 hover:text-brand-green hover:border-brand-green shadow-sm transition z-20"
                                title="Đổi ảnh đại diện">
                                <i class="fas fa-camera text-xs"></i>
                            </button>
                        <?php endif; ?>
                    </div>

                    <h2 class="text-xl font-bold text-gray-800 font-serif"><?php echo e($user->name); ?></h2>
                    <p class="text-gray-500 text-sm mb-3"><?php echo e($user->email); ?></p>

                    <p
                        class="text-gray-600 text-sm italic mb-4 px-2 bg-gray-50 py-2 rounded-lg border border-gray-100 relative">
                        <i class="fas fa-quote-left text-gray-300 absolute top-1 left-1 text-xs"></i>
                        <?php echo e($user->bio ?? 'Thành viên tích cực của Góc Sách.'); ?>

                    </p>

                    <div class="flex justify-center gap-2 mb-6 flex-wrap">
                        <?php if($user->role == 'admin'): ?>
                            <span
                                class="px-3 py-1 bg-red-50 text-red-600 text-xs rounded-full font-bold border border-red-100 flex items-center gap-1">
                                <i class="fas fa-shield-alt"></i> Quản trị viên
                            </span>
                        <?php else: ?>
                            <span
                                class="px-3 py-1 bg-brand-green/10 text-brand-green text-xs rounded-full font-bold border border-brand-green/20">
                                Thành viên
                            </span>
                        <?php endif; ?>

                        <span
                            class="px-3 py-1 bg-green-50 text-green-600 text-xs rounded-full font-medium border border-green-100 flex items-center">
                            <span class="w-1.5 h-1.5 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>
                            <?php echo e($user->is_active ? 'Hoạt động' : 'Đang khóa'); ?>

                        </span>
                    </div>

                    <div class="grid grid-cols-2 gap-3 mb-6 border-t border-b border-gray-100 py-4">
                        <div class="text-center">
                            <span class="block font-bold text-xl text-brand-green"><?php echo e($totalBooks ?? 0); ?></span>
                            <span class="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Sách đề xuất</span>
                        </div>
                        <div class="text-center border-l border-gray-100">
                            <span class="block font-bold text-xl text-brand-accent"><?php echo e($totalReviews ?? 0); ?></span>
                            <span class="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Bài viết</span>
                        </div>

                        <div class="text-center mt-2 pt-2 border-t border-gray-50 col-span-2 grid grid-cols-2">
                            <div class="cursor-pointer hover:bg-gray-50 rounded transition p-1"
                                onclick="openFollowModal('following', <?php echo e($user->id); ?>)">
                                <span class="block font-bold text-lg text-gray-800"><?php echo e($totalFollowing ?? 0); ?></span>
                                <span class="text-xs text-gray-400 uppercase hover:text-blue-500 transition">Đang theo
                                    dõi</span>
                            </div>
                            <div class="cursor-pointer hover:bg-gray-50 rounded transition p-1"
                                onclick="openFollowModal('followers', <?php echo e($user->id); ?>)">
                                <span class="block font-bold text-lg text-gray-800"
                                    id="follower-count"><?php echo e($totalFollowers ?? 0); ?></span>
                                <span class="text-xs text-gray-400 uppercase hover:text-blue-500 transition">Người theo
                                    dõi</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-6 border-t border-b border-gray-100 py-4">
                        <h4 class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3">
                            <i class="fas fa-medal mr-1"></i> Danh Hiệu
                        </h4>

                        <?php if($user->activeBadges && $user->activeBadges->count() > 0): ?>
                            <div class="flex justify-center flex-wrap gap-3">
                                <?php $__currentLoopData = $user->activeBadges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $icon = $badge->icon;
                                        // Kiểm tra xem icon có phải là URL hay không
                                        $isUrl = $icon && (Str::startsWith($icon, 'http') || Str::startsWith($icon, '/'));
                                        // Nếu là URL thì xử lý đường dẫn
                                        $iconUrl = $isUrl
                                            ? (Str::startsWith($icon, 'http') ? $icon : asset('storage/' . $icon))
                                            : null;
                                    ?>

                                    <div class="group relative cursor-help">
                                        <?php if($iconUrl): ?>
                                            
                                            <img src="<?php echo e($iconUrl); ?>" alt="<?php echo e($badge->name); ?>"
                                                class="w-12 h-12 object-contain drop-shadow-sm transform group-hover:scale-110 transition duration-300"
                                                onerror="this.onerror=null; this.parentElement.innerHTML='<div class=\'w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-md\'>🏆</div>';">
                                        <?php elseif($icon && mb_strlen($icon) <= 4): ?>
                                            
                                            <div
                                                class="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-2xl shadow-md transform group-hover:scale-110 transition duration-300">
                                                <?php echo e($icon); ?>

                                            </div>
                                        <?php else: ?>
                                            
                                            <div
                                                class="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-white shadow-md transform group-hover:scale-110 transition duration-300">
                                                <i class="fas fa-medal text-xl"></i>
                                            </div>
                                        <?php endif; ?>

                                        
                                        <div
                                            class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-50 w-max">
                                            <div class="bg-gray-800 text-white text-xs rounded py-1 px-3 shadow-lg text-center">
                                                <div class="font-bold"><?php echo e($badge->name); ?></div>
                                                <?php if($badge->description): ?>
                                                    <div class="text-[10px] text-gray-300 font-normal"><?php echo e($badge->description); ?></div>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <div
                                                class="w-2 h-2 bg-gray-800 transform rotate-45 absolute -bottom-1 left-1/2 -translate-x-1/2">
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            
                            <div class="text-center py-6 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                                <i class="fas fa-medal text-3xl text-gray-300 mb-2"></i>
                                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                                    <p class="text-xs text-gray-400">Bạn chưa có danh hiệu nào</p>
                                    <p class="text-[10px] text-gray-300 mt-1">Hoàn thành thử thách để nhận danh hiệu!</p>
                                <?php else: ?>
                                    <p class="text-xs text-gray-400">Chưa có danh hiệu nào</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    

                    
                    <div class="mb-6 border-t border-b border-gray-100 py-4">
                        <h4 class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3">
                            <i class="fas fa-image mr-1"></i> Khung Avatar
                        </h4>

                        <?php if($user->avatarFrames && $user->avatarFrames->count() > 0): ?>
                            <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                                
                                <div class="grid grid-cols-3 gap-2">
                                    <?php $__currentLoopData = $user->avatarFrames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="relative group cursor-pointer border-2 rounded-lg p-1 transition-all
                                                    <?php echo e($frame->pivot->is_equipped ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-purple-300'); ?>"
                                            onclick="equipFrame(<?php echo e($frame->id); ?>)">

                                            <!-- Frame Preview -->
                                            <div class="aspect-square bg-gray-50 rounded overflow-hidden flex items-center justify-center">
                                                <img src="<?php echo e(Str::startsWith($frame->frame_image, 'http') ? $frame->frame_image : asset('storage/' . $frame->frame_image)); ?>"
                                                    alt="<?php echo e($frame->name); ?>" class="w-full h-full object-contain">
                                            </div>

                                            <!-- Equipped Badge -->
                                            <?php if($frame->pivot->is_equipped): ?>
                                                <div class="absolute -top-1 -right-1 bg-purple-500 text-white text-[8px] px-1 py-0.5 rounded-full font-bold shadow">
                                                    Đang dùng
                                                </div>
                                            <?php endif; ?>

                                            <!-- Tooltip -->
                                            <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-50 w-max">
                                                <div class="bg-gray-800 text-white text-xs rounded py-1 px-2 shadow-lg text-center">
                                                    <div class="font-bold"><?php echo e($frame->name); ?></div>
                                                </div>
                                                <div class="w-2 h-2 bg-gray-800 transform rotate-45 absolute -bottom-1 left-1/2 -translate-x-1/2"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php if($user->equippedFrame()): ?>
                                    <button onclick="unequipFrame()"
                                        class="mt-3 w-full text-[10px] text-gray-500 hover:text-red-500 transition py-1 rounded hover:bg-red-50 border border-transparent hover:border-red-200">
                                        <i class="fas fa-times-circle"></i> Gỡ khung avatar
                                    </button>
                                <?php endif; ?>
                            <?php else: ?>
                                
                                <div class="grid grid-cols-3 gap-2">
                                    <?php $__currentLoopData = $user->avatarFrames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="relative group border-2 rounded-lg p-1 transition-all
                                                    <?php echo e($frame->pivot->is_equipped ? 'border-purple-500 bg-purple-50' : 'border-gray-200'); ?>">

                                            <!-- Frame Preview -->
                                            <div class="aspect-square bg-gray-50 rounded overflow-hidden flex items-center justify-center">
                                                <img src="<?php echo e(Str::startsWith($frame->frame_image, 'http') ? $frame->frame_image : asset('storage/' . $frame->frame_image)); ?>"
                                                    alt="<?php echo e($frame->name); ?>" class="w-full h-full object-contain">
                                            </div>

                                            <!-- Equipped Badge -->
                                            <?php if($frame->pivot->is_equipped): ?>
                                                <div class="absolute -top-1 -right-1 bg-purple-500 text-white text-[8px] px-1 py-0.5 rounded-full font-bold shadow">
                                                    Đang dùng
                                                </div>
                                            <?php endif; ?>

                                            <!-- Tooltip -->
                                            <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-50 w-max">
                                                <div class="bg-gray-800 text-white text-xs rounded py-1 px-2 shadow-lg text-center">
                                                    <div class="font-bold"><?php echo e($frame->name); ?></div>
                                                </div>
                                                <div class="w-2 h-2 bg-gray-800 transform rotate-45 absolute -bottom-1 left-1/2 -translate-x-1/2"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <div class="text-center py-6 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                                <i class="fas fa-image text-3xl text-gray-300 mb-2"></i>
                                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                                    <p class="text-xs text-gray-400">Bạn chưa sở hữu khung avatar nào</p>
                                <?php else: ?>
                                    <p class="text-xs text-gray-400">Chưa sở hữu khung avatar nào</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    


                    <div class="text-xs text-gray-400 space-y-1.5 mb-6 text-left pl-2">
                        <p><i class="far fa-calendar-alt mr-2 w-4 text-center"></i> Tham gia: <span
                                class="text-gray-600"><?php echo e($user->created_at ? $user->created_at->format('d/m/Y') : 'N/A'); ?></span>
                        </p>
                        <p><i class="fas fa-sync-alt mr-2 w-4 text-center"></i> Cập nhật: <span
                                class="text-gray-600"><?php echo e($user->updated_at ? $user->updated_at->format('d/m/Y') : 'N/A'); ?></span>
                        </p>
                    </div>

                    <div class="space-y-2">
                        <?php if(Auth::check() && Auth::id() != $user->id): ?>
                            <button onclick="toggleFollow(<?php echo e($user->id); ?>)" id="btn-follow"
                                class="w-full py-2.5 rounded-lg font-bold transition mb-4 shadow-md flex items-center justify-center gap-2 <?php echo e(Auth::user()->isFollowing($user->id) ? 'bg-gray-200 text-gray-800' : 'bg-blue-600 text-white hover:bg-blue-700'); ?>">
                                <i class="fas <?php echo e(Auth::user()->isFollowing($user->id) ? 'fa-check' : 'fa-user-plus'); ?>"></i>
                                <span id="follow-text">
                                    <?php echo e(Auth::user()->isFollowing($user->id) ? 'Đang theo dõi' : 'Theo dõi'); ?>

                                </span>
                            </button>
                        <?php endif; ?>

                        <?php if(Auth::id() == $user->id): ?>
                            <button onclick="openEditProfileModal()"
                                class="block w-full border border-brand-green text-brand-green py-2 rounded-lg font-bold text-sm hover:bg-brand-green hover:text-white transition">
                                <i class="fas fa-edit mr-1"></i> Chỉnh sửa hồ sơ
                            </button>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button
                                    class="block w-full border border-red-200 text-red-500 py-2 rounded-lg font-bold text-sm hover:bg-red-50 transition mt-2">
                                    <i class="fas fa-sign-out-alt mr-1"></i> Đăng xuất
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-3">

                
                
                
                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                    <div class="bg-white rounded-xl shadow-soft border border-gray-100 mb-6 overflow-hidden">
                        <div class="flex flex-wrap border-b border-gray-100">
                            
                            <button onclick="showProfileTab('overview')" id="tab-btn-overview"
                                class="flex-1 min-w-[120px] px-4 py-4 text-sm font-bold transition-all border-b-2 border-brand-green text-brand-green bg-brand-green/5">
                                <i class="fas fa-th-large mr-2"></i>Tổng quan
                            </button>
                            
                            
                            <button onclick="showProfileTab('reviews')" id="tab-btn-reviews"
                                class="flex-1 min-w-[120px] px-4 py-4 text-sm font-bold transition-all border-b-2 border-transparent text-gray-500 hover:text-brand-green hover:bg-gray-50">
                                <i class="fas fa-pen-nib mr-2"></i>Bài Review
                                <span class="ml-1 bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full"><?php echo e($totalReviews); ?></span>
                            </button>
                            
                            
                            <button onclick="showProfileTab('books')" id="tab-btn-books"
                                class="flex-1 min-w-[120px] px-4 py-4 text-sm font-bold transition-all border-b-2 border-transparent text-gray-500 hover:text-brand-accent hover:bg-gray-50">
                                <i class="fas fa-book-medical mr-2"></i>Sách Đề Xuất
                                <span class="ml-1 bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full"><?php echo e($totalSuggestedBooks); ?></span>
                            </button>
                            
                            
                            <button onclick="showProfileTab('saved')" id="tab-btn-saved"
                                class="flex-1 min-w-[120px] px-4 py-4 text-sm font-bold transition-all border-b-2 border-transparent text-gray-500 hover:text-yellow-600 hover:bg-gray-50">
                                <i class="fas fa-bookmark mr-2"></i>Bài Đã Lưu
                                <span class="ml-1 bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full"><?php echo e($savedPosts->count()); ?></span>
                            </button>
                            
                            
                            <button onclick="showProfileTab('trash')" id="tab-btn-trash"
                                class="flex-1 min-w-[120px] px-4 py-4 text-sm font-bold transition-all border-b-2 border-transparent text-gray-500 hover:text-red-500 hover:bg-gray-50">
                                <i class="fas fa-trash-alt mr-2"></i>Thùng rác
                                <?php if($trashedPosts->count() > 0): ?>
                                    <span class="ml-1 bg-red-100 text-red-600 text-xs px-2 py-0.5 rounded-full"><?php echo e($trashedPosts->count()); ?></span>
                                <?php endif; ?>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>

                
                
                
                <div id="tab-content-overview" class="tab-content">
                    
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                        <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:shadow-md transition">
                            <div class="text-3xl font-bold text-brand-green mb-1"><?php echo e($totalReviews); ?></div>
                            <div class="text-xs text-gray-500 uppercase font-bold tracking-wide">Bài Review</div>
                        </div>
                        <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:shadow-md transition">
                            <div class="text-3xl font-bold text-brand-accent mb-1"><?php echo e($totalSuggestedBooks); ?></div>
                            <div class="text-xs text-gray-500 uppercase font-bold tracking-wide">Sách Đề Xuất</div>
                        </div>
                        <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:shadow-md transition">
                            <div class="text-3xl font-bold text-blue-500 mb-1"><?php echo e($totalFollowing ?? 0); ?></div>
                            <div class="text-xs text-gray-500 uppercase font-bold tracking-wide">Đang Theo Dõi</div>
                        </div>
                        <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:shadow-md transition">
                            <div class="text-3xl font-bold text-purple-500 mb-1"><?php echo e($totalFollowers ?? 0); ?></div>
                            <div class="text-xs text-gray-500 uppercase font-bold tracking-wide">Người Theo Dõi</div>
                        </div>
                    </div>

                    
                    <div class="bg-white rounded-xl shadow-soft border border-gray-100 p-6 mb-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 text-lg flex items-center gap-2">
                                <i class="fas fa-pen-nib text-brand-green"></i> Bài Review Gần Đây
                            </h3>
                            <?php if($totalReviews > 0): ?>
                                <button onclick="showProfileTab('reviews')" class="text-sm text-brand-green font-bold hover:underline">
                                    Xem tất cả <i class="fas fa-arrow-right"></i>
                                </button>
                            <?php endif; ?>
                        </div>

                        <?php if(count($reviews) > 0): ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $reviews->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition group">
                                        <?php
                                            $cover = $post->book->cover_image ?? null;
                                            $coverUrl = $cover ? (Str::startsWith($cover, 'http') ? $cover : asset('storage/' . $cover)) : 'https://placehold.co/50';
                                        ?>
                                        <img src="<?php echo e($coverUrl); ?>" class="w-12 h-16 object-cover rounded shadow-sm flex-shrink-0">
                                        <div class="flex-1 min-w-0">
                                            <h4 class="font-bold text-gray-800 text-sm line-clamp-1 group-hover:text-brand-green transition"><?php echo e($post->title); ?></h4>
                                            <p class="text-xs text-gray-500 mt-0.5"><?php echo e($post->book->title ?? 'Sách đã xóa'); ?></p>
                                            <div class="flex items-center gap-2 mt-1">
                                                <div class="flex text-yellow-400 text-[10px]">
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <i class="fas fa-star <?php echo e($i <= ($post->rating ?? 0) ? '' : 'text-gray-300'); ?>"></i>
                                                    <?php endfor; ?>
                                                </div>
                                                <span class="text-[10px] text-gray-400">• <?php echo e($post->created_at->diffForHumans()); ?></span>
                                                <?php if($post->status == 'pending'): ?>
                                                    <span class="text-[10px] text-yellow-600 bg-yellow-50 px-1.5 py-0.5 rounded font-bold">Chờ duyệt</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php if(Auth::check() && Auth::id() == $post->user_id): ?>
                                            
                                            <a href="<?php echo e(route('reviews.edit', $post->id)); ?>" class="text-blue-500 hover:text-blue-700 self-center opacity-0 group-hover:opacity-100 transition" title="Chỉnh sửa">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            
                                            <?php if($post->status != 'pending_delete'): ?>
                                                <button onclick="requestDeleteReview(<?php echo e($post->id); ?>)" class="text-red-400 hover:text-red-600 self-center opacity-0 group-hover:opacity-100 transition" title="Yêu cầu xóa">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            <?php else: ?>
                                                <button onclick="cancelDeleteReview(<?php echo e($post->id); ?>)" class="text-[10px] text-orange-600 bg-orange-50 hover:bg-orange-100 px-1.5 py-0.5 rounded font-bold self-center transition cursor-pointer" title="Click để hủy yêu cầu xóa">
                                                    <i class="fas fa-undo mr-1"></i>Hủy xóa
                                                </button>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            
                                            <a href="<?php echo e(route('book.reviews', $post->book->slug ?? $post->book_id)); ?>" class="text-brand-green hover:text-brand-green/80 self-center opacity-0 group-hover:opacity-100 transition" title="Xem bài review">
                                                <i class="fas fa-external-link-alt"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-6 text-gray-400">
                                <i class="fas fa-pen-nib text-2xl mb-2"></i>
                                <p class="text-sm">Chưa có bài review nào</p>
                                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                                    <a href="<?php echo e(route('reviews.create')); ?>" class="text-brand-accent text-sm font-bold hover:underline mt-2 inline-block">+ Viết bài đầu tiên</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="bg-white rounded-xl shadow-soft border border-gray-100 p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 text-lg flex items-center gap-2">
                                <i class="fas fa-book-medical text-brand-accent"></i> Sách Đề Xuất Gần Đây
                            </h3>
                            <?php if($totalSuggestedBooks > 0): ?>
                                <button onclick="showProfileTab('books')" class="text-sm text-brand-accent font-bold hover:underline">
                                    Xem tất cả <i class="fas fa-arrow-right"></i>
                                </button>
                            <?php endif; ?>
                        </div>

                        <?php if(count($suggestedBooks) > 0): ?>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                <?php $__currentLoopData = $suggestedBooks->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition group">
                                        <?php
                                            $cover = $book->cover_image ?? null;
                                            $coverUrl = $cover ? (Str::startsWith($cover, 'http') ? $cover : asset('storage/' . $cover)) : 'https://placehold.co/50x75';
                                        ?>
                                        <img src="<?php echo e($coverUrl); ?>" class="w-12 h-16 object-cover rounded shadow-sm flex-shrink-0">
                                        <div class="flex-1 min-w-0">
                                            <h4 class="font-bold text-gray-800 text-sm line-clamp-2 group-hover:text-brand-accent transition"><?php echo e($book->title); ?></h4>
                                            <p class="text-xs text-gray-500 mt-0.5 truncate"><?php echo e($book->author_name ?? 'Tác giả'); ?></p>
                                            <?php if($book->is_approved): ?>
                                                <span class="text-[10px] text-green-600 font-bold"><i class="fas fa-check-circle"></i> Đã duyệt</span>
                                            <?php else: ?>
                                                <span class="text-[10px] text-yellow-600 font-bold"><i class="fas fa-clock"></i> Chờ duyệt</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-6 text-gray-400">
                                <i class="fas fa-book-medical text-2xl mb-2"></i>
                                <p class="text-sm">Chưa đề xuất sách nào</p>
                                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                                    <a href="<?php echo e(route('books.suggest')); ?>" class="text-brand-accent text-sm font-bold hover:underline mt-2 inline-block">+ Đề xuất sách mới</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                
                
                
                <div id="tab-content-reviews" class="tab-content hidden">

                    <div class="flex items-center justify-between mb-6 bg-white rounded-xl shadow-soft border border-gray-100 p-4">
                        <div class="flex items-center gap-3">
                            <h3 class="text-xl font-bold text-gray-800 font-serif border-l-4 border-brand-green pl-3">
                                <?php echo e($totalReviews > 0 ? 'Bài Review Đã Đăng' : 'Chưa có bài viết nào'); ?>

                            </h3>
                            <span class="bg-brand-green/10 text-brand-green text-sm px-3 py-1 rounded-full font-bold"><?php echo e($totalReviews); ?></span>
                        </div>

                        <?php if(Auth::check() && Auth::id() == $user->id): ?>
                            <a href="<?php echo e(route('reviews.create')); ?>"
                                class="inline-flex items-center gap-1.5 bg-brand-accent hover:bg-[#c29263] text-white text-xs font-bold px-4 py-2 rounded-full shadow-sm transition transform hover:-translate-y-0.5">
                                <i class="fas fa-pen-nib"></i> Viết Review mới
                            </a>
                        <?php endif; ?>
                    </div>

                    <div class="space-y-6">
                        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div
                                class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition group relative">

                                
                                <div class="absolute top-4 right-4 z-10">
                                    <?php if($post->status == 'pending'): ?>
                                        <span
                                            class="inline-flex items-center gap-1.5 px-3 py-1 bg-yellow-50 text-yellow-700 text-xs font-bold rounded-full border border-yellow-200 shadow-sm animate-pulse">
                                            <i class="fas fa-clock"></i> Đang chờ duyệt
                                        </span>
                                    <?php elseif($post->status == 'rejected'): ?>
                                        <span
                                            class="inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-700 text-xs font-bold rounded-full border border-red-200 shadow-sm">
                                            <i class="fas fa-times-circle"></i> Bị từ chối
                                        </span>
                                    <?php elseif($post->status == 'published'): ?>
                                        
                                        
                                    <?php endif; ?>
                                </div>

                                
                                <div class="flex justify-between items-start mb-4 pr-20"> 
                                    <div class="flex items-center gap-4">
                                        <a href="<?php echo e(route('book.show', $post->book_id ?? 0)); ?>" class="block shrink-0">
                                            
                                            <?php
                                                $cover = $post->book->cover_image ?? null;
                                                $coverUrl = $cover
                                                    ? (Str::startsWith($cover, 'http') ? $cover : asset('storage/' . $cover))
                                                    : 'https://placehold.co/50';
                                            ?>
                                            <img src="<?php echo e($coverUrl); ?>"
                                                class="w-12 h-16 object-cover rounded shadow-sm border border-gray-200">
                                        </a>

                                        <div>
                                            <h4 class="font-bold text-gray-800 text-base mb-1">
                                                <a href="<?php echo e(route('book.show', $post->book_id ?? 0)); ?>"
                                                    class="hover:text-brand-green transition">
                                                    <?php echo e($post->book->title ?? 'Sách đã xóa'); ?>

                                                </a>
                                            </h4>
                                            <div class="flex text-yellow-400 text-xs items-center gap-2">
                                                <div class="flex">
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <i
                                                            class="fas fa-star <?php echo e($i <= ($post->rating ?? 0) ? '' : 'text-gray-300'); ?>"></i>
                                                    <?php endfor; ?>
                                                </div>
                                                <span class="text-gray-400 text-[11px]">•
                                                    <?php echo e($post->created_at->format('d/m/Y H:i')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                
                                <h3 class="text-lg font-bold text-gray-800 mb-2 group-hover:text-brand-green transition">
                                    <?php echo e($post->title); ?>

                                </h3>

                                
                                <div class="text-gray-500 text-sm line-clamp-3 prose prose-sm max-w-none">
                                    <?php echo $post->content; ?>

                                </div>

                                
                                <div
                                    class="flex items-center justify-between mt-4 text-xs text-gray-400 border-t border-gray-50 pt-3">
                                    <span class="flex items-center gap-2">
                                        <i class="far fa-clock"></i> <?php echo e($post->created_at->diffForHumans()); ?>

                                    </span>

                                    <div class="flex items-center gap-3">
                                        
                                        <?php if(Auth::check() && Auth::id() == $post->user_id): ?>
                                            <a href="<?php echo e(route('reviews.edit', $post->id)); ?>"
                                                class="text-blue-500 hover:text-blue-700 font-bold hover:underline text-xs uppercase tracking-wide flex items-center gap-1 transition">
                                                <i class="fas fa-edit"></i> Sửa
                                            </a>
                                            
                                            <?php if($post->status != 'pending_delete'): ?>
                                                <button onclick="requestDeleteReview(<?php echo e($post->id); ?>)"
                                                    class="text-red-500 hover:text-red-700 font-bold hover:underline text-xs uppercase tracking-wide flex items-center gap-1 transition">
                                                    <i class="fas fa-trash-alt"></i> Xóa
                                                </button>
                                            <?php else: ?>
                                                <button onclick="cancelDeleteReview(<?php echo e($post->id); ?>)"
                                                    class="text-orange-600 hover:text-orange-800 font-bold hover:underline text-xs uppercase tracking-wide flex items-center gap-1 transition cursor-pointer">
                                                    <i class="fas fa-undo"></i> Hủy xóa
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <a href="<?php echo e(route('book.reviews', $post->book->slug ?? $post->book_id)); ?>"
                                            class="text-brand-green font-bold hover:underline text-xs uppercase tracking-wide flex items-center gap-1">
                                            Xem chi tiết <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-10 bg-white rounded-xl border border-dashed border-gray-300">
                                <div
                                    class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3 text-gray-400">
                                    <i class="fas fa-pen-nib text-2xl"></i>
                                </div>
                                <p class="text-gray-500 font-medium">Người dùng này chưa có bài viết nào.</p>
                                <?php if(Auth::check() && Auth::id() == $user->id): ?>
                                    <a href="<?php echo e(route('reviews.create')); ?>"
                                        class="text-brand-accent font-bold hover:underline text-sm">
                                        Viết bài đầu tiên ngay
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <?php if($reviews->hasPages()): ?>
                        <div class="mt-6">
                            <?php echo e($reviews->links()); ?>

                        </div>
                    <?php endif; ?>

                </div>

                
                
                
                <div id="tab-content-books" class="tab-content hidden">
                    <div class="flex items-center justify-between mb-6 bg-white rounded-xl shadow-soft border border-gray-100 p-4">
                        <div class="flex items-center gap-3">
                            <h3 class="text-xl font-bold text-gray-800 font-serif border-l-4 border-brand-accent pl-3">
                                <?php echo e($totalSuggestedBooks > 0 ? 'Sách Tôi Đề Xuất' : 'Chưa có sách đề xuất'); ?>

                            </h3>
                            <span class="bg-brand-accent/10 text-brand-accent text-sm px-3 py-1 rounded-full font-bold"><?php echo e($totalSuggestedBooks); ?></span>
                        </div>

                        <a href="<?php echo e(route('books.suggest')); ?>"
                            class="inline-flex items-center gap-1.5 bg-brand-accent hover:bg-[#c29263] text-white text-xs font-bold px-4 py-2 rounded-full shadow-sm transition transform hover:-translate-y-0.5">
                            <i class="fas fa-plus-circle"></i> Đề xuất sách mới
                        </a>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php $__empty_1 = true; $__currentLoopData = $suggestedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-card hover:-translate-y-1 transition-all duration-300 flex flex-row h-44 relative group">

                                <div class="w-28 relative flex-shrink-0 bg-gray-200">
                                    <?php if($book->is_approved): ?>
                                        <a href="<?php echo e(route('book.show', $book->slug)); ?>">
                                    <?php endif; ?>
                                        <?php
                                            $cover = $book->cover_image ?? null;
                                            $coverUrl = $cover
                                                ? (Str::startsWith($cover, 'http') ? $cover : asset('storage/' . $cover))
                                                : 'https://placehold.co/150x225?text=' . urlencode(Str::limit($book->title, 10));
                                        ?>
                                        <img src="<?php echo e($coverUrl); ?>" class="w-full h-full object-cover transition group-hover:opacity-90">
                                        <?php if($book->is_approved): ?>
                                            </a>
                                        <?php endif; ?>
                                </div>
                                <div class="p-3 flex flex-col justify-between flex-grow min-w-0">
                                    <div>
                                        <h4 class="font-bold font-serif text-gray-800 text-sm mb-1 leading-tight line-clamp-2">
                                            <?php if($book->is_approved): ?>
                                                <a href="<?php echo e(route('book.show', $book->slug)); ?>" class="hover:text-brand-green transition">
                                                    <?php echo e($book->title); ?>

                                                </a>
                                            <?php else: ?>
                                                <?php echo e($book->title); ?>

                                            <?php endif; ?>
                                        </h4>
                                        <p class="text-xs text-gray-500 truncate">
                                            <?php echo e($book->author_name ?? 'Tác giả'); ?>

                                        </p>
                                        <p class="text-[10px] text-gray-400 mt-1">
                                            <i class="far fa-calendar-alt mr-1"></i> Gửi: <?php echo e($book->created_at->format('d/m/Y')); ?>

                                        </p>
                                    </div>

                                    
                                    <div class="mt-auto pt-2">
                                        <?php if($book->is_approved): ?>
                                            <a href="<?php echo e(route('book.show', $book->slug)); ?>"
                                                class="inline-flex items-center gap-1 text-brand-green border border-brand-green/30 bg-brand-green/5 px-2.5 py-1 rounded text-[10px] font-bold hover:bg-brand-green hover:text-white transition">
                                                <i class="fas fa-check-circle"></i> ĐÃ DUYỆT
                                            </a>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1 bg-yellow-50 text-yellow-700 border border-yellow-200 text-[10px] font-bold px-2.5 py-1 rounded">
                                                <i class="fas fa-clock"></i> CHỜ DUYỆT
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-span-full text-center py-10 bg-white rounded-xl border border-dashed border-gray-300">
                                <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3 text-gray-400">
                                    <i class="fas fa-book-medical text-2xl"></i>
                                </div>
                                <p class="text-gray-500 text-sm font-medium">Bạn chưa đề xuất cuốn sách nào.</p>
                                <p class="text-gray-400 text-xs mt-1 mb-3">Hãy đóng góp sách mới cho cộng đồng nhé!</p>
                                <a href="<?php echo e(route('books.suggest')); ?>" class="text-brand-accent text-sm font-bold hover:underline">
                                    + Đề xuất sách ngay
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <?php if($suggestedBooks instanceof \Illuminate\Pagination\LengthAwarePaginator && $suggestedBooks->hasPages()): ?>
                        <div class="mt-6">
                            <?php echo e($suggestedBooks->links()); ?>

                        </div>
                    <?php endif; ?>

                </div>

                
                
                
                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                    <div id="tab-content-saved" class="tab-content hidden">
                        <?php if(isset($savedPosts) && $savedPosts->count() > 0): ?>
                            <div class="space-y-6" id="saved-posts-container">
                                <?php $__currentLoopData = $savedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $savedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition group relative"
                                        id="saved-post-<?php echo e($savedPost->id); ?>">

                                        
                                        <button onclick="handleUnsavePost(<?php echo e($savedPost->id); ?>, this)"
                                            class="absolute top-4 right-4 text-yellow-500 hover:text-gray-400 transition z-10"
                                            title="Bỏ lưu">
                                            <i class="fas fa-bookmark text-lg"></i>
                                        </button>

                                        <div class="flex gap-5">
                                            <?php if($savedPost->book): ?>
                                                <a href="<?php echo e(route('detail', $savedPost->book->slug)); ?>" class="flex-shrink-0">
                                                    <img src="<?php echo e($savedPost->book->cover_image ? (Str::startsWith($savedPost->book->cover_image, 'http') ? $savedPost->book->cover_image : asset('storage/' . $savedPost->book->cover_image)) : 'https://placehold.co/80x120'); ?>"
                                                        class="w-20 h-28 object-cover rounded-lg shadow-sm group-hover:shadow-md transition">
                                                </a>
                                            <?php endif; ?>

                                            <div class="flex-1 min-w-0">
                                                
                                                <div class="flex items-center gap-2 mb-2">
                                                    <a href="<?php echo e(route('public.profile', $savedPost->user->id)); ?>">
                                                        <img src="<?php echo e($savedPost->user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($savedPost->user->name)); ?>"
                                                            class="w-7 h-7 rounded-full border border-gray-200">
                                                    </a>
                                                    <a href="<?php echo e(route('public.profile', $savedPost->user->id)); ?>"
                                                        class="text-sm text-gray-700 hover:text-brand-green font-medium">
                                                        <?php echo e($savedPost->user->name); ?>

                                                    </a>
                                                    <span class="text-gray-300">•</span>
                                                    <span
                                                        class="text-xs text-gray-400"><?php echo e($savedPost->created_at->diffForHumans()); ?></span>
                                                </div>

                                                <?php if($savedPost->book): ?>
                                                    <a href="<?php echo e(route('detail', $savedPost->book->slug)); ?>"
                                                        class="text-xs text-brand-green font-bold uppercase tracking-wider hover:underline mb-1 block">
                                                        <?php echo e($savedPost->book->title); ?>

                                                    </a>
                                                <?php endif; ?>

                                                <?php if($savedPost->title): ?>
                                                    <h4
                                                        class="font-bold text-gray-800 text-lg mb-2 group-hover:text-brand-green transition line-clamp-2">
                                                        "<?php echo e($savedPost->title); ?>"
                                                    </h4>
                                                <?php endif; ?>

                                                <div class="text-gray-500 text-sm line-clamp-3 mb-3">
                                                    <?php echo Str::limit(strip_tags($savedPost->content), 200); ?>

                                                </div>

                                                
                                                <div class="flex items-center gap-5 pt-3 border-t border-gray-100">
                                                    <?php
                                                        $isLiked = Auth::check() && $savedPost->likes->where('user_id', Auth::id())->count() > 0;
                                                    ?>
                                                    <button onclick="handleLike(<?php echo e($savedPost->id); ?>, 'post')"
                                                        id="like-btn-post-<?php echo e($savedPost->id); ?>"
                                                        class="flex items-center gap-2 text-sm font-bold transition <?php echo e($isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'); ?>">
                                                        <i id="like-icon-post-<?php echo e($savedPost->id); ?>"
                                                            class="<?php echo e($isLiked ? 'fas' : 'far'); ?> fa-heart"></i>
                                                        <span
                                                            id="like-count-post-<?php echo e($savedPost->id); ?>"><?php echo e($savedPost->likes_count ?? 0); ?></span>
                                                    </button>

                                                    <button onclick="toggleSavedComment(<?php echo e($savedPost->id); ?>)"
                                                        class="flex items-center gap-2 text-sm font-bold text-gray-500 hover:text-blue-500 transition">
                                                        <i class="far fa-comment-dots"></i>
                                                        <span
                                                            id="comment-count-<?php echo e($savedPost->id); ?>"><?php echo e($savedPost->comments_count ?? 0); ?></span>
                                                    </button>

                                                    <?php if($savedPost->book): ?>
                                                        <a href="<?php echo e(route('book.reviews', $savedPost->book->slug)); ?>#post-<?php echo e($savedPost->id); ?>"
                                                            class="text-brand-green font-bold hover:underline text-sm ml-auto flex items-center gap-1">
                                                            Xem chi tiết <i class="fas fa-arrow-right"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>

                                                
                                                <div id="saved-comment-box-<?php echo e($savedPost->id); ?>"
                                                    class="hidden mt-4 pt-4 border-t border-dashed border-gray-100">
                                                    <?php if($savedPost->comments && $savedPost->comments->count() > 0): ?>
                                                        <div
                                                            class="space-y-2 mb-3 pl-3 border-l-2 border-gray-100 max-h-40 overflow-y-auto">
                                                            <?php $__currentLoopData = $savedPost->comments->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="flex gap-2">
                                                                    <img src="<?php echo e($comment->user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($comment->user->name)); ?>"
                                                                        class="w-6 h-6 rounded-full mt-0.5">
                                                                    <div class="bg-gray-50 px-3 py-2 rounded-lg text-sm flex-1">
                                                                        <span class="font-bold text-gray-700"><?php echo e($comment->user->name); ?></span>
                                                                        <span class="text-gray-600 ml-2"><?php echo e($comment->content); ?></span>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    <?php endif; ?>

                                                    <form onsubmit="submitSavedComment(<?php echo e($savedPost->id); ?>, event)"
                                                        class="flex gap-2 items-center">
                                                        <?php echo csrf_field(); ?>
                                                        <img src="<?php echo e(Auth::user()->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode(Auth::user()->name)); ?>"
                                                            class="w-8 h-8 rounded-full">
                                                        <input type="text" name="content" required
                                                            class="flex-1 px-4 py-2 text-sm border border-gray-200 rounded-full focus:outline-none focus:border-brand-green"
                                                            placeholder="Viết bình luận...">
                                                        <button type="submit"
                                                            class="text-brand-green hover:text-brand-green-light px-2">
                                                            <i class="fas fa-paper-plane"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-10 bg-white rounded-xl border border-dashed border-gray-300">
                                <div
                                    class="w-16 h-16 bg-yellow-50 rounded-full flex items-center justify-center mx-auto mb-3 text-yellow-400">
                                    <i class="fas fa-bookmark text-2xl"></i>
                                </div>
                                <p class="text-gray-500 font-medium">Bạn chưa lưu bài viết nào.</p>
                                <p class="text-gray-400 text-sm mt-1">Nhấn biểu tượng <i class="far fa-bookmark"></i> trên bài
                                    review để lưu lại.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                
                
                
                <?php if(isset($isOwnProfile) && $isOwnProfile): ?>
                    <div id="tab-content-trash" class="tab-content hidden">
                        <div class="bg-white rounded-xl shadow-soft border border-gray-100 p-6">
                            <div class="flex items-center justify-between mb-6">
                                <h3 class="font-bold text-lg text-gray-800">
                                    <i class="fas fa-trash-alt text-red-400 mr-2"></i>Thùng rác
                                </h3>
                                <span class="text-xs text-gray-400">Bài viết đã xóa có thể khôi phục</span>
                            </div>

                            <?php if($trashedPosts->count() > 0): ?>
                                <div class="space-y-4">
                                    <?php $__currentLoopData = $trashedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-200 group hover:bg-gray-100 transition">
                                            
                                            <?php if($post->book && $post->book->cover_image): ?>
                                                <img src="<?php echo e(Str::startsWith($post->book->cover_image, 'http') ? $post->book->cover_image : asset('storage/' . $post->book->cover_image)); ?>"
                                                     alt="<?php echo e($post->book->title); ?>"
                                                     class="w-12 h-16 object-cover rounded shadow-sm flex-shrink-0 opacity-60">
                                            <?php else: ?>
                                                <div class="w-12 h-16 bg-gray-200 rounded flex items-center justify-center flex-shrink-0">
                                                    <i class="fas fa-book text-gray-400"></i>
                                                </div>
                                            <?php endif; ?>

                                            
                                            <div class="flex-1 min-w-0">
                                                <h4 class="font-bold text-gray-700 truncate line-through"><?php echo e($post->title); ?></h4>
                                                <p class="text-xs text-gray-400 mt-1">
                                                    <i class="fas fa-book mr-1"></i><?php echo e($post->book->title ?? 'Sách đã xóa'); ?>

                                                </p>
                                                <p class="text-xs text-red-400 mt-1">
                                                    <i class="fas fa-trash mr-1"></i>Đã xóa: <?php echo e($post->deleted_at->diffForHumans()); ?>

                                                </p>
                                            </div>

                                            
                                            <div class="flex items-center gap-2 flex-shrink-0">
                                                <button onclick="restoreReview(<?php echo e($post->id); ?>)"
                                                    class="px-3 py-2 bg-green-500 hover:bg-green-600 text-white text-xs font-bold rounded-lg transition transform hover:scale-105 flex items-center gap-1">
                                                    <i class="fas fa-undo"></i> Khôi phục
                                                </button>
                                                <button onclick="forceDeleteReview(<?php echo e($post->id); ?>)"
                                                    class="px-3 py-2 bg-red-500 hover:bg-red-600 text-white text-xs font-bold rounded-lg transition transform hover:scale-105 flex items-center gap-1">
                                                    <i class="fas fa-times"></i> Xóa vĩnh viễn
                                                </button>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div class="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                                    <p class="text-sm text-yellow-700">
                                        <i class="fas fa-info-circle mr-2"></i>
                                        Bài viết trong thùng rác sẽ được giữ vô thời hạn. Bạn có thể khôi phục bất cứ lúc nào.
                                    </p>
                                </div>
                            <?php else: ?>
                                
                                <div class="text-center py-12">
                                    <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                        <i class="fas fa-trash-alt text-3xl text-gray-300"></i>
                                    </div>
                                    <h4 class="font-bold text-gray-600 mb-2">Thùng rác trống</h4>
                                    <p class="text-sm text-gray-400">Không có bài viết nào trong thùng rác.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

            </div>

        </div>

        
        <div id="followModal" class="fixed inset-0 z-[60] hidden" aria-labelledby="modal-title" role="dialog"
            aria-modal="true">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onclick="closeFollowModal()"></div>

            <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
                <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                    <div
                        class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-md">
                        <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4 border-b border-gray-100">
                            <div class="flex items-center justify-between">
                                <h3 class="text-lg font-bold leading-6 text-gray-900" id="modal-title">Danh sách</h3>
                                <button onclick="closeFollowModal()" class="text-gray-400 hover:text-gray-600 transition">
                                    <i class="fas fa-times text-xl"></i>
                                </button>
                            </div>
                        </div>

                        <div class="bg-white px-4 py-2 sm:p-6 max-h-[400px] overflow-y-auto" id="modal-body">
                            <div class="flex justify-center py-4">
                                <i class="fas fa-spinner fa-spin text-brand-green text-2xl"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>

    <script>
        // --- 0. Xử lý chuyển đổi Tab Profile ---
        function showProfileTab(tabName) {
            // Danh sách các tab
            const tabs = ['overview', 'reviews', 'books', 'saved', 'trash'];
            
            // Ẩn tất cả nội dung tab
            tabs.forEach(tab => {
                const content = document.getElementById(`tab-content-${tab}`);
                const btn = document.getElementById(`tab-btn-${tab}`);
                
                if (content) {
                    content.classList.add('hidden');
                }
                
                if (btn) {
                    btn.classList.remove('border-brand-green', 'text-brand-green', 'bg-brand-green/5');
                    btn.classList.remove('border-brand-accent', 'text-brand-accent', 'bg-brand-accent/5');
                    btn.classList.remove('border-yellow-500', 'text-yellow-600', 'bg-yellow-50');
                    btn.classList.remove('border-red-500', 'text-red-500', 'bg-red-50');
                    btn.classList.add('border-transparent', 'text-gray-500');
                }
            });
            
            // Hiển thị tab được chọn
            const activeContent = document.getElementById(`tab-content-${tabName}`);
            const activeBtn = document.getElementById(`tab-btn-${tabName}`);
            
            if (activeContent) {
                activeContent.classList.remove('hidden');
            }
            
            if (activeBtn) {
                activeBtn.classList.remove('border-transparent', 'text-gray-500');
                
                // Màu sắc khác nhau cho mỗi tab
                if (tabName === 'overview' || tabName === 'reviews') {
                    activeBtn.classList.add('border-brand-green', 'text-brand-green', 'bg-brand-green/5');
                } else if (tabName === 'books') {
                    activeBtn.classList.add('border-brand-accent', 'text-brand-accent', 'bg-brand-accent/5');
                } else if (tabName === 'saved') {
                    activeBtn.classList.add('border-yellow-500', 'text-yellow-600', 'bg-yellow-50');
                } else if (tabName === 'trash') {
                    activeBtn.classList.add('border-red-500', 'text-red-500', 'bg-red-50');
                }
            }
        }

        // Auto-switch tab dựa trên URL parameters (khi phân trang)
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            
            if (urlParams.has('review_page')) {
                showProfileTab('reviews');
            } else if (urlParams.has('book_page')) {
                showProfileTab('books');
            }
        });

        // --- 1. Xử lý Nút Toggle Follow (Một hàm duy nhất) ---
        function toggleFollow(userId) {
            fetch('<?php echo e(route('follow.toggle')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ user_id: userId })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'error') { alert(data.message); return; }

                    const btn = document.getElementById('btn-follow');
                    const text = document.getElementById('follow-text');
                    const icon = btn.querySelector('i');
                    const countSpan = document.getElementById('follower-count');

                    if (data.follower_count !== undefined) countSpan.innerText = data.follower_count;

                    if (data.action === 'followed') {
                        btn.classList.remove('bg-blue-600', 'text-white', 'hover:bg-blue-700');
                        btn.classList.add('bg-gray-200', 'text-gray-800');
                        text.innerText = 'Đang theo dõi';
                        icon.className = 'fas fa-check';
                    } else {
                        btn.classList.remove('bg-gray-200', 'text-gray-800');
                        btn.classList.add('bg-blue-600', 'text-white', 'hover:bg-blue-700');
                        text.innerText = 'Theo dõi';
                        icon.className = 'fas fa-user-plus';
                    }
                })
                .catch(error => console.error('Lỗi Follow:', error));
        }

        // --- 2. Xử lý Modal Danh sách Follow ---
        function openFollowModal(type, userId) {
            const modal = document.getElementById('followModal');
            const title = document.getElementById('modal-title');
            const body = document.getElementById('modal-body');

            // Reset nội dung loading
            body.innerHTML = '<div class="flex justify-center py-4"><i class="fas fa-spinner fa-spin text-brand-green text-2xl"></i></div>';

            // Hiện modal
            modal.classList.remove('hidden');

            // Đặt tiêu đề
            if (type === 'followers') title.innerText = 'Người theo dõi';
            else title.innerText = 'Đang theo dõi';

            // Gọi API lấy danh sách
            fetch(`/api/user/${userId}/${type}`)
                .then(res => res.json())
                .then(users => {
                    body.innerHTML = ''; // Xóa loading

                    if (users.length === 0) {
                        body.innerHTML = '<p class="text-center text-gray-500 py-4 text-sm">Chưa có ai trong danh sách này.</p>';
                        return;
                    }

                    // Vẽ danh sách user
                    let html = '<div class="space-y-3">';
                    users.forEach(u => {
                        // Logic lấy avatar (Nếu null thì dùng UI Avatars)
                        const avatar = u.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name)}&background=random`;

                        // Link tới profile người đó
                        html += `
                                    <a href="/profile/${u.id}" class="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg transition group border border-transparent hover:border-gray-100">
                                        <img src="${avatar}" class="w-10 h-10 rounded-full border border-gray-200 object-cover">
                                        <div>
                                            <h4 class="font-bold text-gray-800 text-sm group-hover:text-brand-green transition">${u.name}</h4>
                                        </div>
                                        <div class="ml-auto">
                                            <span class="text-xs text-gray-400 group-hover:text-brand-green"><i class="fas fa-chevron-right"></i></span>
                                        </div>
                                    </a>
                                `;
                    });
                    html += '</div>';
                    body.innerHTML = html;
                })
                .catch(err => {
                    console.error(err);
                    body.innerHTML = '<p class="text-center text-red-500 py-4 text-sm">Không thể tải dữ liệu.</p>';
                });
        }

        function closeFollowModal() {
            document.getElementById('followModal').classList.add('hidden');
        }

        // Đóng modal khi nhấn ESC
        document.addEventListener('keydown', function (event) {
            if (event.key === "Escape") {
                closeFollowModal();
                closeEditProfileModal();
            }
        });

        // --- 3. Xử lý Modal Chỉnh sửa Hồ sơ ---
        function openEditProfileModal() {
            document.getElementById('editProfileModal').classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // Prevent scroll
        }

        function closeEditProfileModal() {
            document.getElementById('editProfileModal').classList.add('hidden');
            document.body.style.overflow = ''; // Restore scroll
        }

        // Xem trước ảnh khi chọn file
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                    // Xóa URL input khi chọn file
                    document.getElementById('avatarUrlInput').value = '';
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Xem trước ảnh từ URL
        function previewAvatarUrl(url) {
            if (url) {
                document.getElementById('avatarPreview').src = url;
                // Xóa file input khi nhập URL
                document.getElementById('avatarInput').value = '';
            }
        }

        // Chuyển tab upload avatar
        function showAvatarTab(type) {
            const fileTab = document.getElementById('avatar-tab-file');
            const urlTab = document.getElementById('avatar-tab-url');
            const fileDiv = document.getElementById('avatar-upload-file');
            const urlDiv = document.getElementById('avatar-upload-url');

            if (type === 'file') {
                fileTab.classList.remove('bg-gray-100', 'text-gray-600');
                fileTab.classList.add('bg-brand-green/10', 'text-brand-green');
                urlTab.classList.remove('bg-brand-green/10', 'text-brand-green');
                urlTab.classList.add('bg-gray-100', 'text-gray-600');
                fileDiv.classList.remove('hidden');
                urlDiv.classList.add('hidden');
            } else {
                urlTab.classList.remove('bg-gray-100', 'text-gray-600');
                urlTab.classList.add('bg-brand-green/10', 'text-brand-green');
                fileTab.classList.remove('bg-brand-green/10', 'text-brand-green');
                fileTab.classList.add('bg-gray-100', 'text-gray-600');
                urlDiv.classList.remove('hidden');
                fileDiv.classList.add('hidden');
            }
        }

        // Submit form chỉnh sửa hồ sơ
        function submitEditProfile(event) {
            event.preventDefault();

            const form = document.getElementById('editProfileForm');
            const formData = new FormData(form);
            const submitBtn = document.getElementById('editProfileSubmitBtn');
            const errorDiv = document.getElementById('editProfileError');

            // Disable button và hiện loading
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Đang lưu...';
            errorDiv.classList.add('hidden');

            fetch('<?php echo e(route("profile.update")); ?>', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                },
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Cập nhật giao diện với dữ liệu mới
                        document.querySelectorAll('[data-user-name]').forEach(el => {
                            el.textContent = data.user.name;
                        });
                        document.querySelectorAll('[data-user-bio]').forEach(el => {
                            el.textContent = data.user.bio || 'Thành viên tích cực của Góc Sách.';
                        });
                        document.querySelectorAll('[data-user-avatar]').forEach(el => {
                            el.src = data.user.avatar;
                        });

                        // Đóng modal và reload trang để hiển thị đúng
                        closeEditProfileModal();
                        window.location.reload();
                    } else {
                        errorDiv.textContent = data.message || 'Có lỗi xảy ra!';
                        errorDiv.classList.remove('hidden');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    errorDiv.textContent = 'Có lỗi xảy ra, vui lòng thử lại!';
                    errorDiv.classList.remove('hidden');
                })
                .finally(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fas fa-save mr-2"></i> Lưu thay đổi';
                });
        }

        // --- 4. Xử lý trang bị khung avatar ---
        function equipFrame(frameId) {
            fetch('<?php echo e(route("profile.avatar-frame.equip")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ avatar_frame_id: frameId })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.error || 'Có lỗi xảy ra!');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Có lỗi xảy ra khi trang bị khung!');
                });
        }

        function unequipFrame() {
            fetch('<?php echo e(route("profile.avatar-frame.unequip")); ?>', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        // --- 5. Yêu cầu xóa bài review (chờ admin duyệt) ---
        function requestDeleteReview(postId) {
            if (!confirm('Bạn có chắc muốn yêu cầu xóa bài review này?\n\nYêu cầu sẽ được gửi đến Admin để xử lý.')) {
                return;
            }

            fetch(`/reviews/${postId}/request-delete`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert(data.message || 'Có lỗi xảy ra!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi gửi yêu cầu xóa!');
            });
        }

        // --- 6. Hủy yêu cầu xóa bài review ---
        function cancelDeleteReview(postId) {
            if (!confirm('Bạn có chắc muốn hủy yêu cầu xóa và khôi phục bài viết này?')) {
                return;
            }

            fetch(`/reviews/${postId}/cancel-delete`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert(data.message || 'Có lỗi xảy ra!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi hủy yêu cầu xóa!');
            });
        }

        // --- 7. Khôi phục bài review từ thùng rác ---
        function restoreReview(postId) {
            if (!confirm('Bạn có chắc muốn khôi phục bài viết này?')) {
                return;
            }

            fetch(`/reviews/${postId}/restore`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert(data.message || 'Có lỗi xảy ra!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi khôi phục bài viết!');
            });
        }

        // --- 8. Xóa vĩnh viễn bài review ---
        function forceDeleteReview(postId) {
            if (!confirm('⚠️ CẢNH BÁO: Hành động này không thể hoàn tác!\n\nBạn có chắc chắn muốn xóa vĩnh viễn bài viết này?')) {
                return;
            }

            fetch(`/reviews/${postId}/force-delete`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert(data.message || 'Có lỗi xảy ra!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi xóa bài viết!');
            });
        }
    </script>

    
    
    
    <?php if(Auth::check() && Auth::id() == $user->id): ?>
        <div id="editProfileModal" class="fixed inset-0 z-[70] hidden" aria-labelledby="edit-profile-title" role="dialog"
            aria-modal="true">
            
            <div class="fixed inset-0 bg-gray-900/60 backdrop-blur-sm transition-opacity" onclick="closeEditProfileModal()">
            </div>

            <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
                <div class="flex min-h-full items-center justify-center p-4">
                    <div
                        class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all w-full max-w-md">

                        
                        <div class="bg-gradient-to-r from-brand-green to-emerald-600 px-6 py-4">
                            <div class="flex items-center justify-between">
                                <h3 class="text-lg font-bold text-white flex items-center gap-2" id="edit-profile-title">
                                    <i class="fas fa-user-edit"></i> Chỉnh sửa hồ sơ
                                </h3>
                                <button onclick="closeEditProfileModal()" class="text-white/80 hover:text-white transition p-1">
                                    <i class="fas fa-times text-xl"></i>
                                </button>
                            </div>
                        </div>

                        
                        <form id="editProfileForm" onsubmit="submitEditProfile(event)" enctype="multipart/form-data"
                            class="p-6">

                            
                            <div id="editProfileError"
                                class="hidden mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-2 rounded-lg text-sm">
                            </div>

                            
                            <div class="mb-6">
                                <label class="block text-sm font-semibold text-gray-700 mb-3 text-center">
                                    <i class="fas fa-image mr-1 text-brand-green"></i> Ảnh đại diện
                                </label>
                                
                                
                                <div class="flex justify-center mb-4">
                                    <div class="relative group">
                                        <img id="avatarPreview"
                                            src="<?php echo e($user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=3E5F4E&color=fff&size=128'); ?>"
                                            class="w-28 h-28 rounded-full border-4 border-brand-beige shadow-lg object-cover">
                                    </div>
                                </div>

                                
                                <div class="flex gap-2 justify-center mb-3">
                                    <button type="button" onclick="showAvatarTab('file')" id="avatar-tab-file"
                                        class="px-3 py-1.5 text-xs rounded-full bg-brand-green/10 text-brand-green font-bold transition">
                                        <i class="fas fa-upload mr-1"></i> Upload File
                                    </button>
                                    <button type="button" onclick="showAvatarTab('url')" id="avatar-tab-url"
                                        class="px-3 py-1.5 text-xs rounded-full bg-gray-100 text-gray-600 font-bold transition">
                                        <i class="fas fa-link mr-1"></i> Nhập URL
                                    </button>
                                </div>

                                
                                <div id="avatar-upload-file" class="text-center">
                                    <label for="avatarInput"
                                        class="cursor-pointer inline-flex items-center gap-2 px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition text-sm font-medium text-gray-600">
                                        <i class="fas fa-cloud-upload-alt"></i> Chọn ảnh từ máy
                                    </label>
                                    <input type="file" id="avatarInput" name="avatar" accept=".jpg,.jpeg,.png,.webp,.gif,.svg" class="hidden"
                                        onchange="previewAvatar(this)">
                                    <p class="text-xs text-gray-400 mt-2">JPG, PNG, WebP, GIF, SVG (Tối đa 2MB)</p>
                                </div>

                                
                                <div id="avatar-upload-url" class="hidden">
                                    <input type="url" name="avatar_url" id="avatarUrlInput"
                                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-green/30 focus:border-brand-green transition text-gray-800 text-sm"
                                        placeholder="https://example.com/avatar.jpg"
                                        oninput="previewAvatarUrl(this.value)">
                                    <p class="text-xs text-gray-400 mt-2 text-center">Dán đường dẫn trực tiếp đến file ảnh</p>
                                </div>
                            </div>

                            
                            <div class="mb-4">
                                <label for="editName" class="block text-sm font-semibold text-gray-700 mb-1.5">
                                    <i class="fas fa-user mr-1 text-brand-green"></i> Tên hiển thị <span
                                        class="text-red-500">*</span>
                                </label>
                                <input type="text" id="editName" name="name" value="<?php echo e($user->name); ?>" required maxlength="100"
                                    class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-green/30 focus:border-brand-green transition text-gray-800"
                                    placeholder="Nhập tên hiển thị...">
                            </div>

                            
                            <div class="mb-6">
                                <label for="editBio" class="block text-sm font-semibold text-gray-700 mb-1.5">
                                    <i class="fas fa-quote-left mr-1 text-brand-accent"></i> Giới thiệu bản thân
                                </label>
                                <textarea id="editBio" name="bio" rows="3" maxlength="500"
                                    class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-green/30 focus:border-brand-green transition text-gray-800 resize-none"
                                    placeholder="Viết vài dòng về bản thân..."><?php echo e($user->bio); ?></textarea>
                                <p class="text-xs text-gray-400 mt-1 text-right"><span
                                        id="bioCharCount"><?php echo e(strlen($user->bio ?? '')); ?></span>/500 ký tự</p>
                            </div>

                            
                            <div class="flex gap-3">
                                <button type="button" onclick="closeEditProfileModal()"
                                    class="flex-1 py-2.5 border border-gray-200 text-gray-600 rounded-lg font-semibold hover:bg-gray-50 transition">
                                    Hủy bỏ
                                </button>
                                <button type="submit" id="editProfileSubmitBtn"
                                    class="flex-1 py-2.5 bg-brand-green text-white rounded-lg font-semibold hover:bg-brand-green/90 transition flex items-center justify-center gap-2 shadow-md">
                                    <i class="fas fa-save"></i> Lưu thay đổi
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Đếm ký tự bio
            document.getElementById('editBio').addEventListener('input', function () {
                document.getElementById('bioCharCount').textContent = this.value.length;
            });

            // Handle Unsave Post (Bỏ lưu bài viết)
            function handleUnsavePost(postId, btnElement) {
                if (!confirm('Bạn có chắc muốn bỏ lưu bài viết này?')) return;

                // Visual feedback
                btnElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                btnElement.disabled = true;

                fetch('/post/save', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({ post_id: postId })
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && !data.saved) {
                            // Xóa card bài viết với animation
                            const card = document.getElementById(`saved-post-${postId}`);
                                    if (card) {
                                        card.style.transition = 'all 0.3s ease-out';
                                        card.style.opacity = '0';
                                        card.style.transform = 'translateX(-20px)';
                                        setTimeout(() => {
                                            card.remove();
                                            // Update counter in tab
                                            const countSpan = document.querySelector('#tab-btn-saved span');
                                            if (countSpan) {
                                                let count = parseInt(countSpan.textContent) - 1;
                                                countSpan.textContent = count;
                                            }
                                            // Check if empty
                                            const container = document.getElementById('saved-posts-container');
                                            if (container && container.children.length === 0) {
                                                location.reload();
                                            }
                                        }, 300);
                                    }
                                } else {
                                    btnElement.innerHTML = '<i class="fas fa-bookmark"></i>';
                                    btnElement.disabled = false;
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                btnElement.innerHTML = '<i class="fas fa-bookmark"></i>';
                                btnElement.disabled = false;
                            });
                        }

                        // Toggle Comment Box for Saved Posts
                        function toggleSavedComment(postId) {
                            const box = document.getElementById(`saved-comment-box-${postId}`);
                            if (box) {
                                box.classList.toggle('hidden');
                                // Focus input when shown
                                if (!box.classList.contains('hidden')) {
                                    const input = box.querySelector('input[name="content"]');
                                    if (input) input.focus();
                                }
                            }
                        }

                        // Handle Like for Saved Posts  
                        function handleLike(id, type) {
                            const btn = document.getElementById(`like-btn-${type}-${id}`);
                            const icon = document.getElementById(`like-icon-${type}-${id}`);
                            const countSpan = document.getElementById(`like-count-${type}-${id}`);

                            if (!btn || !icon || !countSpan) return;

                            const isLiked = icon.classList.contains('fas');

                            // Optimistic update
                            if (isLiked) {
                                icon.classList.remove('fas', 'text-red-500');
                                icon.classList.add('far');
                                btn.classList.remove('text-red-500');
                                btn.classList.add('text-gray-500');
                                countSpan.textContent = Math.max(0, parseInt(countSpan.textContent) - 1);
                            } else {
                                icon.classList.remove('far');
                                icon.classList.add('fas', 'text-red-500');
                                btn.classList.remove('text-gray-500');
                                btn.classList.add('text-red-500');
                                countSpan.textContent = parseInt(countSpan.textContent) + 1;
                            }

                            // Send AJAX
                            fetch('/like', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                },
                                body: JSON.stringify({ id: id, type: type })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    countSpan.textContent = data.count;
                                }
                            })
                            .catch(error => console.error('Error:', error));
                        }

                        // Submit Comment for Saved Posts
                        function submitSavedComment(postId, event) {
                            event.preventDefault();

                            const form = event.target;
                            const input = form.querySelector('input[name="content"]');
                            const content = input.value.trim();

                            if (!content) return;

                            // Disable form
                            input.disabled = true;
                            const submitBtn = form.querySelector('button[type="submit"]');
                            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

                            fetch(`/post/${postId}/comment`, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                },
                                body: JSON.stringify({ content: content })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    // Update count
                                    const countSpan = document.getElementById(`comment-count-${postId}`);
                                    if (countSpan) {
                                        countSpan.textContent = parseInt(countSpan.textContent) + 1;
                                    }

                                    // Clear input
                                    input.value = '';

                                    // Add new comment to list
                                    const commentBox = document.getElementById(`saved-comment-box-${postId}`);
                                    const commentList = commentBox.querySelector('.space-y-2');
                                    if (commentList && data.comment) {
                                        const newComment = document.createElement('div');
                                        newComment.className = 'flex gap-2';
                                        newComment.innerHTML = `
                                            <img src="<?php echo e(Auth::user()->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode(Auth::user()->name)); ?>" 
                                                 class="w-6 h-6 rounded-full mt-0.5">
                                            <div class="bg-gray-50 px-3 py-2 rounded-lg text-sm flex-1">
                                                <span class="font-bold text-gray-700"><?php echo e(Auth::user()->name); ?></span>
                                                <span class="text-gray-600 ml-2">${content}</span>
                                            </div>
                                        `;
                                        commentList.prepend(newComment);
                                    }
                                } else {
                                    alert(data.message || 'Có lỗi xảy ra');
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                alert('Không thể gửi bình luận. Vui lòng thử lại.');
                            })
                            .finally(() => {
                                input.disabled = false;
                                submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
                            });
                        }
                    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/profile.blade.php ENDPATH**/ ?>