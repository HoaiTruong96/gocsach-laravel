<?php if(isset($latestReviews) && $latestReviews->count() > 0): ?>
    <div class="grid grid-cols-1 gap-4 sm:gap-6">
        <?php $__currentLoopData = $latestReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $book = $comment->post->book ?? null;
            ?>
            
            <div class="bg-white rounded-2xl p-3 sm:p-5 border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300">

                
                <div class="flex justify-between items-start mb-3">
                    <div class="flex items-center gap-3">
                        <a href="<?php echo e(route('public.profile', $comment->user->id)); ?>" class="flex-shrink-0">
                            <?php echo $__env->make('partials.user-avatar-with-frame', [
                                'user' => $comment->user,
                                'size' => 'w-12 h-12',
                                'avatarSize' => 'w-10 h-10'
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </a>
                        <div>
                            <div class="flex items-center gap-1">
                                <a href="<?php echo e(route('public.profile', $comment->user->id)); ?>"
                                    class="hover:text-brand-green transition">
                                    <h4 class="font-bold text-gray-800 text-sm"><?php echo e($comment->user->name); ?></h4>
                                </a>
                                <?php echo $__env->make('partials.user-badges', ['user' => $comment->user, 'size' => 'xs'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                            <div class="text-xs text-gray-500 flex items-center gap-1">
                                <span>Đánh giá về:</span>
                                <?php if($book): ?>
                                    <a href="<?php echo e(route('detail', $book->slug ?? '#')); ?>"
                                        class="font-bold text-brand-green hover:underline">
                                        <?php echo e($book->title ?? 'Sách ẩn'); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-400">Sách không xác định</span>
                                <?php endif; ?>
                                <span class="text-gray-300 mx-1">•</span>
                                <span><?php echo e($comment->created_at->diffForHumans()); ?></span>
                            </div>
                        </div>
                    </div>

                    
                    <?php if($comment->rating): ?>
                        <div class="flex items-center gap-1 bg-yellow-50 px-2 py-1 rounded-full">
                            <i class="fas fa-star text-yellow-400 text-xs"></i>
                            <span class="text-xs font-bold text-yellow-600"><?php echo e(number_format($comment->rating, 1)); ?></span>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="mb-4 pl-1">
                    <div class="bg-gray-50 rounded-xl p-3 text-gray-700 text-sm leading-relaxed relative">
                        <?php echo e($comment->content); ?>

                    </div>
                </div>

                
                <div class="flex items-center justify-between pt-2 border-t border-gray-50">
                    <div class="flex gap-3 md:gap-4">
                        <button onclick="handleLike(<?php echo e($comment->id); ?>, 'comment')" id="like-btn-comment-<?php echo e($comment->id); ?>"
                            class="flex items-center gap-1.5 md:gap-1 text-xs font-bold <?php echo e(Auth::check() && $comment->likes->contains('user_id', Auth::id()) ? 'text-red-500' : 'text-gray-500 hover:text-red-500'); ?> transition">
                            <i id="like-icon-comment-<?php echo e($comment->id); ?>"
                                class="<?php echo e(Auth::check() && $comment->likes->contains('user_id', Auth::id()) ? 'fas' : 'far'); ?> fa-heart"></i>
                            <span class="hidden md:inline">Thích</span>
                            <span id="like-count-comment-<?php echo e($comment->id); ?>"><?php echo e($comment->likes_count ?? 0); ?></span>
                        </button>

                        <button onclick="toggleReplySection(<?php echo e($comment->id); ?>)"
                            class="flex items-center gap-1.5 md:gap-1 text-xs font-bold text-gray-500 hover:text-brand-green transition group">
                            <i class="far fa-comment-dots group-hover:scale-110 transition-transform"></i>
                            <span class="hidden md:inline">Trả lời</span> <span id="reply-count-<?php echo e($comment->id); ?>">(<?php echo e($comment->replies->count()); ?>)</span>
                            <i id="chevron-reply-<?php echo e($comment->id); ?>"
                                class="fas fa-chevron-down text-[10px] ml-1 transition-transform duration-300"></i>
                        </button>

                        
                        <?php if(auth()->guard()->check()): ?>
                            <?php if($comment->user_id !== Auth::id()): ?>
                                <button onclick="openReportModal(<?php echo e($comment->id); ?>, 'comment')"
                                    class="flex items-center gap-1 text-xs font-bold text-gray-400 hover:text-red-500 transition"
                                    title="Báo cáo bình luận này">
                                    <i class="far fa-flag"></i>
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    
                    <?php if($book): ?>
                        <a href="<?php echo e(route('detail', $book->slug ?? '#')); ?>"
                            class="text-xs text-brand-green font-bold hover:underline">
                            Xem sách →
                        </a>
                    <?php endif; ?>
                </div>

                
                <div id="reply-section-<?php echo e($comment->id); ?>"
                    class="hidden mt-4 pt-4 border-t border-dashed border-gray-100 bg-gray-50/50 rounded-xl p-4 animate-fade-in">

                    
                    <div class="space-y-4 mb-4">
                        <?php $__empty_1 = true; $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div id="comment-<?php echo e($reply->id); ?>" class="flex gap-2 scroll-mt-24 transition-all duration-500">
                                <a href="<?php echo e(route('public.profile', $reply->user->id)); ?>" class="flex-shrink-0">
                                    <?php echo $__env->make('partials.user-avatar-with-frame', [
                                        'user' => $reply->user,
                                        'size' => 'w-9 h-9',
                                        'avatarSize' => 'w-7 h-7'
                                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </a>
                                <div class="flex-1">
                                    <div class="bg-white p-2 rounded-xl rounded-tl-none border border-gray-100 shadow-sm">
                                        <div class="flex justify-between items-center mb-1">
                                            <div class="flex items-center gap-1">
                                                <a href="<?php echo e(route('public.profile', $reply->user->id)); ?>"
                                                    class="hover:text-brand-green transition">
                                                    <h6 class="font-bold text-[10px] text-gray-700"><?php echo e($reply->user->name); ?></h6>
                                                </a>
                                                <?php echo $__env->make('partials.user-badges', ['user' => $reply->user, 'size' => 'xs'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                            </div>
                                            <span class="text-[9px] text-gray-400"><?php echo e($reply->created_at->diffForHumans()); ?></span>
                                        </div>
                                        <p class="text-[11px] text-gray-600"><?php echo e($reply->content); ?></p>
                                    </div>
                                    
                                    <div class="flex items-center gap-2 ml-2 mt-1">
                                        <button onclick="handleLike(<?php echo e($reply->id); ?>, 'comment')" id="like-btn-comment-<?php echo e($reply->id); ?>"
                                            class="text-[9px] font-bold flex items-center gap-1 <?php echo e(Auth::check() && $reply->likes->contains('user_id', Auth::id()) ? 'text-red-500' : 'text-gray-400'); ?>">
                                            <i id="like-icon-comment-<?php echo e($reply->id); ?>"
                                                class="<?php echo e(Auth::check() && $reply->likes->contains('user_id', Auth::id()) ? 'fas' : 'far'); ?> fa-heart"></i>
                                            <span id="like-count-comment-<?php echo e($reply->id); ?>"><?php echo e($reply->likes->count()); ?></span>
                                        </button>
                                        
                                        <?php if(auth()->guard()->check()): ?>
                                            <?php if($reply->user_id !== Auth::id()): ?>
                                                <button onclick="openReportModal(<?php echo e($reply->id); ?>, 'comment')"
                                                    class="text-[9px] font-bold text-gray-400 hover:text-red-500 transition"
                                                    title="Báo cáo">
                                                    <i class="far fa-flag"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center text-xs text-gray-400 italic py-2">Chưa có phản hồi nào.</p>
                        <?php endif; ?>
                    </div>

                    
                    <?php if(auth()->guard()->check()): ?>
                        <div class="flex gap-2 items-start">
                            <?php echo $__env->make('partials.user-avatar-with-frame', [
                                'user' => Auth::user(),
                                'size' => 'w-9 h-9',
                                'avatarSize' => 'w-7 h-7'
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <div class="flex-1 relative">
                                <textarea id="reply-input-<?php echo e($comment->id); ?>" rows="1"
                                    class="w-full text-xs p-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-brand-green resize-none pr-16 shadow-sm"
                                    placeholder="Nhập phản hồi..." oninput="autoResize(this)"></textarea>
                                <button type="button" onclick="submitReply(<?php echo e($comment->id); ?>, event)"
                                    class="absolute right-1.5 top-1 text-brand-green px-2 py-1 bg-brand-green/10 rounded-lg text-xs font-bold hover:bg-brand-green hover:text-white transition">
                                    Gửi
                                </button>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-xs text-gray-400 italic">
                            <a href="<?php echo e(route('login')); ?>" class="text-brand-green font-bold hover:underline">Đăng nhập</a> để trả
                            lời bình luận này.
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php if($latestReviews->hasPages()): ?>
        <div class="mt-8 flex justify-center">
            <nav class="inline-flex items-center bg-white rounded-full shadow-sm border border-gray-200 px-2 py-1">
                <?php if(!$latestReviews->onFirstPage()): ?>
                    <a href="<?php echo e($latestReviews->previousPageUrl()); ?>"
                        class="ajax-pagination-link p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-brand-green transition mr-2">
                        <i class="fas fa-chevron-left text-sm"></i>
                    </a>
                <?php endif; ?>
                <?php for($i = max(1, $latestReviews->currentPage() - 2); $i <= min($latestReviews->lastPage(), $latestReviews->currentPage() + 2); $i++): ?>
                    <?php if($i == $latestReviews->currentPage()): ?>
                        <span class="px-3 py-1 rounded-full bg-brand-green text-white font-bold mx-1 text-xs"><?php echo e($i); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($latestReviews->url($i)); ?>"
                            class="ajax-pagination-link px-3 py-1 rounded-full text-gray-600 hover:bg-gray-100 transition mx-1 text-xs"><?php echo e($i); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if($latestReviews->hasMorePages()): ?>
                    <a href="<?php echo e($latestReviews->nextPageUrl()); ?>"
                        class="ajax-pagination-link p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-brand-green transition ml-2">
                        <i class="fas fa-chevron-right text-sm"></i>
                    </a>
                <?php endif; ?>
            </nav>
        </div>
    <?php endif; ?>
<?php else: ?>
    <div class="text-center py-10 bg-white rounded-2xl border border-dashed border-gray-200">
        <i class="far fa-comments text-4xl text-gray-300 mb-3"></i>
        <p class="text-gray-500 text-sm">Chưa có bình luận nào từ cộng đồng.</p>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/partials/home_comments.blade.php ENDPATH**/ ?>