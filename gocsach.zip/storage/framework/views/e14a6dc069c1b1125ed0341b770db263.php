<table class="w-full text-left border-collapse">
    <thead
        class="bg-gray-50 dark:bg-slate-800 text-gray-500 dark:text-slate-400 text-xs uppercase border-b dark:border-slate-700">
        <tr>
            <th class="px-4 py-3 w-12 text-center">#</th>
            <th class="px-4 py-3">Thành viên</th>
            <th class="px-4 py-3 w-56">Email</th>
            <th class="px-4 py-3 text-center w-28 whitespace-nowrap">Vai trò</th>
            <th class="px-4 py-3 text-center w-20 whitespace-nowrap">Bài viết</th>
            <th class="px-4 py-3 text-center w-28 whitespace-nowrap">Ngày tham gia</th>
            <th class="px-4 py-3 text-center w-16"></th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-100 dark:divide-slate-700">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50 dark:hover:bg-slate-700/50 group transition">
                <td class="px-5 py-4 text-center text-gray-400 dark:text-slate-500 text-sm">
                    <?php echo e(($users->currentPage() - 1) * $users->perPage() + $index + 1); ?>

                </td>
                <td class="px-5 py-4">
                    <div class="flex items-center gap-3">
                        <img src="<?php echo e($user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=random'); ?>"
                            class="w-10 h-10 rounded-full border dark:border-slate-600 object-cover <?php echo e(!$user->is_active ? 'opacity-50 grayscale' : ''); ?>">
                        <div>
                            <span
                                class="font-bold text-gray-800 dark:text-white <?php echo e(!$user->is_active ? 'line-through opacity-60' : ''); ?>"><?php echo e($user->name); ?></span>
                            <?php if(!$user->is_active): ?>
                                <span
                                    class="ml-2 inline-flex items-center px-1.5 py-0.5 bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-300 rounded text-xs font-bold">
                                    <i class="fas fa-ban mr-1 text-[10px]"></i>Đã khóa
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </td>
                <td class="px-5 py-4 text-sm text-gray-600 dark:text-slate-300 max-w-[220px] truncate"
                    title="<?php echo e($user->email); ?>"><?php echo e($user->email); ?></td>
                <td class="px-4 py-4 text-center">
                    <?php if($user->role === 'admin'): ?>
                        <span
                            class="inline-flex items-center px-2.5 py-1 bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 rounded-full text-xs font-bold whitespace-nowrap">
                            <i class="fas fa-shield-alt mr-1"></i>Admin
                        </span>
                    <?php else: ?>
                        <span
                            class="inline-flex items-center px-2.5 py-1 bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 rounded-full text-xs font-bold whitespace-nowrap">
                            <i class="fas fa-user mr-1"></i>Thành viên
                        </span>
                    <?php endif; ?>
                </td>
                <td class="px-5 py-4 text-center">
                    <span
                        class="inline-flex items-center justify-center px-2 py-0.5 bg-green-100 dark:bg-green-900/40 text-green-600 dark:text-green-300 text-xs font-bold rounded-full min-w-[40px]">
                        <?php echo e($user->posts_count); ?>

                    </span>
                </td>
                <td class="px-5 py-4 text-center text-sm text-gray-500 dark:text-slate-400 italic">
                    <?php echo e($user->created_at->format('d/m/Y')); ?>

                </td>
                <td class="px-5 py-4 text-center">
                    <?php if($user->role !== 'admin'): ?>
                        <form action="<?php echo e(route('admin.users.toggle-active', $user->id)); ?>" method="POST"
                            onsubmit="return confirm('<?php echo e($user->is_active ? 'Vô hiệu hóa' : 'Kích hoạt'); ?> tài khoản <?php echo e($user->name); ?>?');">
                            <?php echo csrf_field(); ?>
                            <?php if($user->is_active): ?>
                                <button
                                    class="w-8 h-8 flex items-center justify-center rounded-full bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-300 hover:bg-orange-500 dark:hover:bg-orange-600 hover:text-white transition opacity-0 group-hover:opacity-100"
                                    title="Vô hiệu hóa">
                                    <i class="fas fa-ban text-xs"></i>
                                </button>
                            <?php else: ?>
                                <button
                                    class="w-8 h-8 flex items-center justify-center rounded-full bg-green-100 dark:bg-green-900/40 text-green-600 dark:text-green-300 hover:bg-green-500 dark:hover:bg-green-600 hover:text-white transition"
                                    title="Kích hoạt lại">
                                    <i class="fas fa-check text-xs"></i>
                                </button>
                            <?php endif; ?>
                        </form>
                    <?php else: ?>
                        <span
                            class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 dark:bg-slate-600 text-gray-400 dark:text-slate-500"
                            title="Admin không thể vô hiệu hóa">
                            <i class="fas fa-lock text-xs"></i>
                        </span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center py-12 text-gray-400 dark:text-slate-500">
                    <i class="fas fa-search text-4xl mb-3"></i>
                    <p>Không tìm thấy thành viên nào</p>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/admin/users/_table.blade.php ENDPATH**/ ?>