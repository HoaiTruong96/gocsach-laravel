

<?php
    $containerSize = $size ?? 'w-12 h-12';
    $avatarSize = $avatarSize ?? 'w-10 h-10';
    $showFrame = $showFrame ?? true;
    $equippedFrame = $showFrame ? $user->equippedFrame() : null;
    $avatarUrl = $user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=random&size=128';
?>

<div class="relative <?php echo e($containerSize); ?> inline-block flex-shrink-0">
    <!-- Avatar Frame (if equipped) -->
    <?php if($equippedFrame): ?>
        <img src="<?php echo e(Str::startsWith($equippedFrame->frame_image, 'http') ? $equippedFrame->frame_image : asset('storage/' . $equippedFrame->frame_image)); ?>"
             alt="Frame"
             class="absolute inset-0 w-full h-full object-contain pointer-events-none z-10">
    <?php endif; ?>
    
    <!-- User Avatar -->
    <div class="absolute inset-0 flex items-center justify-center z-0">
        <img src="<?php echo e($avatarUrl); ?>" 
             alt="<?php echo e($user->name); ?>"
             class="<?php echo e($avatarSize); ?> rounded-full object-cover border-2 border-gray-200">
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\gocsach-laravel\resources\views/partials/user-avatar-with-frame.blade.php ENDPATH**/ ?>