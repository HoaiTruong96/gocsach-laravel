<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up()
    {
        Schema::create('follows', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('follower_id'); // Người đi theo dõi (Ví dụ: Bạn)
            $table->unsignedBigInteger('following_id'); // Người được theo dõi (Ví dụ: Admin)
            $table->timestamps();

            // Ràng buộc: Một người chỉ được follow người kia 1 lần (tránh trùng lặp)
            $table->unique(['follower_id', 'following_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('follows');
    }
};
